#!/bin/bash
cd /Volumes/
ls /Volumes/
