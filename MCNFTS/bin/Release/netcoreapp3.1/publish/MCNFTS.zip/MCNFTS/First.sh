#!/bin/bash
sudo chmod -x MCNFTS
sudo chmod 777 MCNFTS
sudo chmod -x list.sh
sudo chmod 777 list.sh
./MCNFTS
